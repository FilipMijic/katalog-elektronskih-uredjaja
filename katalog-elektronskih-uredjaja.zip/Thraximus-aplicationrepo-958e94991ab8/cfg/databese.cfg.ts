export const DatabaseCfg =
{
    hostname: 'localhost',
    username: 'aplikacija',
    password: "aplikacija",
    database: "ekatalogzaelektronskeuredjaje"
};