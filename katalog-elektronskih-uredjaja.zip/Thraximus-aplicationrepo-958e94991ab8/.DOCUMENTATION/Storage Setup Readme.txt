Potrebno je napraviti sledecu konfiguraciju foldera u istom direktorijumu kao backend

"storage" u kome se nalazi "img" u kome se dalje nalaze jos 3 foldera "smal"|"thumb"|"normal"